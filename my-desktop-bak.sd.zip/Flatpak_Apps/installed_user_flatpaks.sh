flatpak install --user io.gitlab.adhami3310.Impression -y
flatpak install --user com.vysp3r.ProtonPlus -y
flatpak install --user com.google.Chrome -y
flatpak install --user io.dbeaver.DBeaverCommunity -y
flatpak install --user com.mattjakeman.ExtensionManager -y
flatpak install --user com.ranfdev.DistroShelf -y
flatpak install --user com.getpostman.Postman -y
flatpak install --user com.github.tchx84.Flatseal -y
