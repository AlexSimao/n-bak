flatpak install --system com.discordapp.Discord -y
flatpak install --system com.github.Matoking.protontricks -y
flatpak install --system com.github.ztefn.haguichi -y
flatpak install --system io.github.vikdevelop.SaveDesktop -y
flatpak install --system net.nokyan.Resources -y
flatpak install --system org.localsend.localsend_app -y
flatpak install --system org.onlyoffice.desktopeditors -y
flatpak install --system org.videolan.VLC -y
