flatpak install --system io.github.vikdevelop.SaveDesktop -y
flatpak install --system net.nokyan.Resources -y
flatpak install --system org.localsend.localsend_app -y
