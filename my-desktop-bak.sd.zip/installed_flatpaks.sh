flatpak install --system com.github.ztefn.haguichi -y
flatpak install --system com.ranfdev.DistroShelf -y
flatpak install --system io.github.vikdevelop.SaveDesktop -y
flatpak install --system org.gnome.clocks -y
flatpak install --system org.gnome.Loupe -y
flatpak install --system org.gnome.Papers -y
flatpak install --system org.gnome.TextEditor -y
flatpak install --system org.videolan.VLC -y
